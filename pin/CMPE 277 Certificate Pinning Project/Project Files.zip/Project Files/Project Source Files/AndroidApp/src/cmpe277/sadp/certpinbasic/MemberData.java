package cmpe277.sadp.certpinbasic;
// used for MemberData pulled from Web service
public class MemberData {
	private double locLatCoord;
	private double locLongCoord;
	private String status;
	private String name;
	private int memberId;

}
