package cmpe277.sadp.memberlists;

import android.app.ListFragment;

public class MemberListFragment extends ListFragment {

}
