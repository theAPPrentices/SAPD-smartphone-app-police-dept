package cmpe277.sadp.certpinbasic;

import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.util.Log;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;

import android.os.AsyncTask;
import co.infinum.https.*;

import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.lang.InterruptedException;

/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment implements OnClickListener,
		RadioGroup.OnCheckedChangeListener {

	@Override
	public void onCheckedChanged(RadioGroup group, int checkedId) {
		if (R.id.opt_custom == checkedId) {
			// User wants to use custom URL
			userInput.setVisibility(EditText.VISIBLE);
		} else {
			// Hide custom URL input
			userInput.setVisibility(EditText.INVISIBLE);
		}

	}

	// Password used for bks file
	private static final char[] STORE_PASS = new char[] { 's', 'a', 'd', 'p',
			's', 'e', 'c', 'r', 'e', 't' };

	private View rootView;
	private static final String MAIN_FRAG_TAG = "MainFragment";

	private Button testButton;

	private RadioGroup optionGroup;
	private EditText userInput;

	@Override
	public void onClick(View v) {
		// Check which button is clicked, by comparing R.id.button == v.getId()
		switch (v.getId()) {
		case (R.id.btn_test_pin): {
			testRequest();
			Log.i(MAIN_FRAG_TAG,
					"Button Clicked, test pin v.getId() = " + v.getId());
			break;
		}
		default:
			Log.i(MAIN_FRAG_TAG,
					"Button Clicked, no action required v.getId() = "
							+ v.getId());

		}

	}

	public MainActivityFragment() {
		// TODO Create Pinned HTTP Client
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		rootView = inflater.inflate(R.layout.fragment_cert_pin_main, container,
				false);

		// Set on Click Listener
		testButton = (Button) rootView.findViewById(R.id.btn_test_pin);
		testButton.setOnClickListener(this);

		// Reference for Radio Group
		optionGroup = (RadioGroup) rootView.findViewById(R.id.opt_group);
		optionGroup.setOnCheckedChangeListener(this);

		// Reference EditText
		userInput = (EditText) rootView.findViewById(R.id.in_user_custom);

		return rootView;
	}

	private void testRequest() {

		// Read URL based on radio button
		String url = "";
		switch (optionGroup.getCheckedRadioButtonId()) {

		case (R.id.opt_pin):
			url = ((RadioButton) rootView.findViewById(R.id.opt_pin)).getText()
					.toString();
			break;
		case (R.id.opt_nopin):
			url = ((RadioButton) rootView.findViewById(R.id.opt_nopin))
					.getText().toString();
			break;
		case (R.id.opt_custom):
			url = ((EditText) rootView.findViewById(R.id.in_user_custom))
					.getText().toString();
			break;
		default:
			Log.i(MAIN_FRAG_TAG, "No Valid option selected");

		}
		if (URLUtil.isValidUrl(url)) {

			PinWebPageTask testPin = new PinWebPageTask();
			try {
				testPin.execute(getApacheRequest(url));

				HttpResponse response = testPin.get();
				if (response != null)
					Toast.makeText(getActivity(),
							"Response: " + response.getStatusLine().toString(),
							Toast.LENGTH_LONG).show();
				else
					Toast.makeText(getActivity(), "No Peer Certificate",
							Toast.LENGTH_LONG).show();
			} catch (InterruptedException e) {
			} catch (ExecutionException e) {
			} catch (CancellationException e) {
			}
			// TODO Make the request
		} else {
			Toast.makeText(getActivity(),
					"Please Select a valid option or use a valid custom URL",
					Toast.LENGTH_LONG).show();
			return;
		}

	}

	private HttpGet getApacheRequest(String url) {
		HttpGet request = new HttpGet(url);
		request.addHeader("User-Agent", "hello-pinnedcerts");

		return request;

	}

	private class PinWebPageTask extends AsyncTask<HttpGet, Void, HttpResponse> {
		@Override
		protected HttpResponse doInBackground(HttpGet... request) {
			HttpResponse response = null;
			try {
				DefaultHttpClient httpClient = new HttpClientBuilder()
						.setConnectionTimeout(10000)
						.setSocketTimeout(60000)
						.setHttpPort(80)
						.setHttpsPort(443)
						.setCookieStore(new BasicCookieStore())
						.pinCertificates(getResources(), R.raw.sadp_keystore,
								STORE_PASS).build();

				response = httpClient.execute(request[0]);

			} catch (IOException e) {
				e.printStackTrace();
			} catch (CertificateException e) {
				e.printStackTrace();
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} catch (KeyStoreException e) {
				e.printStackTrace();
			}
			return response;
		}
	}

}