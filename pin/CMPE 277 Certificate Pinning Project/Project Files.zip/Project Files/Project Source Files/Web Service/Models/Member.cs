﻿using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace SadpWebRest.Models
{
    public class Member
    {
        public int MemberID { get; set; }
        public string Name { get; set; }
        public double LocLongCoord { get; set; }
        public double LocLatCoord { get; set; }
        public string Status { get; set; }
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
    }
}